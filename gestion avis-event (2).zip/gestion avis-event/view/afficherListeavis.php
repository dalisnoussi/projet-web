<?php
    require '../controller/avisC.php';

    $avisd = new avisC();
    $aviss = $avisd->afficheravis();
?>




<!DOCTYPE html>
<html>

<?php  $i=1?>

 <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
 <link href="../assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
 <link rel="stylesheet" href="../assets/css/style.css">
 <link rel="stylesheet" href="../assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
 <link rel="stylesheet" href="../assets/vendor/charts/chartist-bundle/chartist.css">
 <link rel="stylesheet" href="../assets/css/style.css">
 <link rel="stylesheet" href="../assets/vendor/charts/morris-bundle/morris.css">
 <link rel="stylesheet" href="../assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
 <link rel="stylesheet" href="../assets/vendor/charts/c3charts/c3.css">

 <div class="col-xl-9 col-lg-12 col-md-6 col-sm-12 col-12">

 <a class="btn btn-outline-light float-right" href=".../gestion evenement(back)/back html file.html">retour a la page d'accueil</a>

                                <div class="card">
                                    <h5 class="card-header">les avis</h5>
                                    
                                    <div class="card-body p-0">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead class="bg-light">

                                                  
                                                    <tr class="border-0">
                                                        <th class="border-0">#</th>
                                                        <th class="border-0">titre d'evenement</th>
                                                        <th class="border-0">commentaire</th>
                                                        <th class="border-0">note</th>
                                                       
                                                        <th class="border-0">id avis</th>

                                                    </tr>
                                                </thead>
                                                <tbody>

                                                
                                                 <?php 
                                                  foreach($aviss as $avis){
                                                    ?>
                                                    <tr>
                                                        <td> <?php echo $i++; ?></td>
                                                        <td><?php echo $avis['titreevent'] ; ?></td>
                                                      <td><?php echo $avis['cmntrevent'] ; ?></td>
                                                      <td><?php echo $avis['noteevent'] ; ?></td>
                                                      <td><?php echo $avis['idavis'] ; ?></td>

                                                        
                                                      <td> <a href="supprimeravis.php?idavis=<?php echo $avis['idavis']; ?>"><img src="stop.png" width='30px' height='30px'> </a> </td>
                                                      <td> <a href="modifieravis.php ?idavis=<?php echo  $avis['idavis']; ?>">modifier <img src="modifier.png" width='30px' height='30px'> </a>  </td>

                                                        
                                                        
                                                    </tr>
                                                    <?php
                                                    }
                                                    ?>

                                            
                                                   
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>





</html>



