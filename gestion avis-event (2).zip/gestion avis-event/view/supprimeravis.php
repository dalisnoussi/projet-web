<?php
    require '../controller/avisC.php';

    $avisC = new avisC();
    $avisC->supprimeravis($_GET['idavis']);
    header('Location:afficherListeavis.php');

    
?>









