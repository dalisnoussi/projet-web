
<?php
require 'D:\XAMPP\htdocs\partie evenement officielle\gestion evenement(front)\controller\eventC.php';

$eventd=new eventc();
$evenements=$eventd->afficherevent();



 
?>
  <script src="../js/readmore.js"></script>
 

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="">
    <link rel="stylesheet" href="../css/boutons.css">
    <!-- JavaScript Bundle with Popper -->
    <link rel="stylesheet" href="../css/boutons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    <title>NADHAFNI</title>
    <link rel="stylesheet" type="text/css" href="../assets/css/formulaire_event.css">

</head>



    
<header>

    <input type="checkbox" name="" id="toggler">
    <label for="toggler" class="fas fa-bars"></label>

    <img class="logo" src="logo.png" alt="logo">

    <nav class="navbar">
        <a href="#home">Acceuil</a>
        <a href="#about">Reclamation Lieu</a>
        <a  class="event_sec" href="front event.php">Evenements</a> 
        <a href="#products">Boutiques</a>
        <a href="action.html">Actions Individuelles</a>  
        <a href="#review">Forum</a>
        <a href="#contact">contact</a>

    </nav>

    <div class="icons">
        <a href="#" class="fas fa-heart"></a>
        <a href="#" class="fas fa-shopping-cart"></a>
        <a href="#" class="fas fa-user"></a>
    </div>

</header>



<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>









<?php 
   foreach($evenements as $value){
   ?>
<section class="container">

 <div  class="card">
    <div class="card_image img1" ></div>
    <h2 class="title_event"><?php echo $value["nomevent"]; ?> (lieu: <?php echo $value["lieuevent"]; ?>)</h2>

    <P class="date_event"><?php echo $value["dateevent"]; ?></P>


    <p><span class="descrip_event" id="dots"></span><span id="more"><?php echo $value["descripevent"]; ?></span></p>

 <button  type="button" class="btn_lire" onclick="readmore()" id="myBtn">lire plus </button> 
   
    <a href="formulaire_event.html" class="btn_particip">Participer</a>

 </div>

  <?php
  }
  ?>



 


       


</section>

<footer>

    <section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="#">Acceuil</a>
            <a href="#">A propos Nous</a>
            <a href="#">Produits</a>
            <a href="#">review</a>
            <a href="#">contact</a>
        </div>
      
        <div class="box">
            <h3>Social Media</h3>
            <i class="fab fa-facebook"></i> <br>
           <i class="fab fa-instagram"></i><br>
           <i class="fab fa-youtube"></i><br>

             
    
        </div>

        <div class="box">
            <h3>locations</h3>
            <a href="#">Ariana</a>
            <a href="#">Nabeul</a>
            <a href="#">Sousse</a>
            <a href="#">Tunis</a>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <a href="#">+216 28 683 199</a>
            <a href="#">NADHAFNI@gmail.com</a>
            <a href="#">Petite Ariana</a>
            <img src="images/payment.png" alt="">
        </div>

    </div>

   <div class="credit"> created by <span> The Mythical Developers </span> | all rights reserved </div>
</footer>

</section>
