<?php

    require_once '../config.php';
    require_once '../Model/avis.php';


    Class avisC {

        function afficheravis()
        {
            $requete = "select * from avis";
            $config = config::getConnexion();
            try {
                $querry = $config->prepare($requete);
                $querry->execute();
                $result = $querry->fetchAll();
                return $result ;
            } catch (PDOException $th) {
                 $th->getMessage();
            }
        }


        function getavisbyID($id)
        {
            $requete = "select * from avis where idavis=:id";
            $config = config::getConnexion();
            try {
                $querry = $config->prepare($requete);
                $querry->execute(
                    [
                        'id'=>$id
                    ]
                );
                $result = $querry->fetch();
                return $result ;
            } catch (PDOException $th) {
                 $th->getMessage();
            }
        }






        function ajouteravis($avis)
        {
            $config = config::getConnexion();
            try {
                $querry = $config->prepare('
                INSERT INTO avis
                (titreevent,cmntrevent,noteevent)
                VALUES
                (:titreevent,:cmntrevent,:noteevent)
                ');
                $querry->execute([
                    
                    'titreevent'=>$avis->gettitreevent(),
                    'cmntrevent'=>$avis->getcmntrevent(),
                    'noteevent'=>$avis->getnoteevent(),
                    
                ]);
            } catch (PDOException $th) {
                 $th->getMessage();
            }
        }














        function modifieravis($avis,$idavis)
        {
            $config = config::getConnexion();
            try {
                $querry = $config->prepare(
                'UPDATE avis SET  titreevent=:titreevent,cmntrevent=:cmntrevent,noteevent=:noteevent
               
                where idavis=:idavis');

                $querry->execute([
                    'idavis'=>$idavis,
                    'titreevent'=>$avis->gettitreevent(),
                    'cmntrevent'=>$avis->getcmntrevent(),
                    'noteevent'=>$avis->getnoteevent(),
                    
                ]);
            } catch (PDOException $th) {
                 $th->getMessage();
            }
        }











        function supprimeravis($id)
        {
            $config = config::getConnexion();
            try {
                $querry = $config->prepare(
                'DELETE FROM avis WHERE idavis =:id
                ');
                $querry->execute([
                    'id'=>$id
                ]);
                
            } catch (PDOException $th) {
                 $th->getMessage();
            }
        }
    }

?>