<?php




    
    require_once '../controller/eventC.php';
    require_once '../controller/avisC.php';
    $eventc = new eventc();
    $resultats = $eventc -> afficherevent();

   if (isset($_POST['fkevent']))
   {    
    $list=$eventc->afficher_avis($_POST['fkevent']);
    $avisd = new avisC();
    $aviss = $avisd->afficher_avis($_POST['fkevent']);
    
   }
   else {
    $avisd = new avisC();
    $aviss = $avisd->afficheravis();
  }

?>




<!DOCTYPE html>
<html>

<link rel="stylesheet" href="../css/search.css">
<?php  $i=1?>

 <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
 <link href="../assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
 <link rel="stylesheet" href="../assets/css/style.css">
 <link rel="stylesheet" href="../assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
 <link rel="stylesheet" href="../assets/vendor/charts/chartist-bundle/chartist.css">
 <link rel="stylesheet" href="../assets/css/style.css">
 <link rel="stylesheet" href="../assets/vendor/charts/morris-bundle/morris.css">
 <link rel="stylesheet" href="../assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
 <link rel="stylesheet" href="../assets/vendor/charts/c3charts/c3.css">

 <div class="col-xl-9 col-lg-12 col-md-6 col-sm-12 col-12">


 <form id="form" action="" method="POST" >

 <select name="fkevent">
                     <option value="" >choisir l'evenement-</option>

                     <?php foreach ($resultats as $value) {
                      ?>
                      <option value="<?php echo($value["idevent"])?>"> <?php echo($value["nomevent"])?></option>

                      <?php }?>
                     </select>


      <input type="submit" value="chercher"  name="search" src="../images/search.png" width='30px' height='30px'>>

      </form>




 <a class="btn btn-outline-light float-right" href="../back html file.html">retour a la page d'accueil</a>

                                <div class="card">
                                    <h5 class="card-header">les avis</h5>
                                    
                                    <div class="card-body p-0">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead class="bg-light">

                                                  
                                                    <tr class="border-0">
                                                        <th class="border-0">#</th>
                                                        <th class="border-0">id avis</th>
                                                        <th class="border-0">titre d'evenement</th>
                                                        <th class="border-0">commentaire</th>
                                                        <th class="border-0">note</th>
                                                        <th class="border-0">id event</th>
                                                        

                                                    </tr>
                                                </thead>
                                                <tbody>

                                                
                                          
                                                <?php 
                                                  foreach($aviss as $avis){
                                                    ?>
                                                    <tr>
                                                        <td> <?php echo $i++; ?></td>
                                                        <td><?php echo $avis['idavis'] ; ?></td>
                                                        <td><?php echo $avis['titreevent'] ; ?></td>
                                                      <td><?php echo $avis['cmntrevent'] ; ?></td>
                                                      <td><?php echo $avis['noteevent'] ; ?></td>
                                                      <td><?php echo $avis['fkevent'] ; ?></td>

                                                        

                                                        
                                                        
                                                    </tr>
                                                    <?php
                                                    }
                                                    ?>
                                            
                                                   
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>





</html>



