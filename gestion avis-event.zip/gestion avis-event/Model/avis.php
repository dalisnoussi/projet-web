<?php


    class avis
    {   
        private $titreevent;
        private $cmntrevent;
        private $noteevent;
		private $fkevent;
		private $idavis;

        function __construct($idavis,$titreevent,$cmntrevent,$noteevent,$fkevent){
			$this->idavis=$idavis;
			$this->titreevent=$titreevent;
			$this->cmntrevent=$cmntrevent;
			$this->noteevent=$noteevent;
			$this->fkevent=$fkevent;
		}
	
		
        function settitreevent(string $titreevent){
			$this->titreevent=$titreevent;
		}
        function setcmntrevent(string $cmntrevent){
			$this->cmntrevent=$cmntrevent;
		}
        function setnoteevent(int $noteevent){
			$this->noteevent=$noteevent;
		}
        function setfkevent(int $fkevent){
			$this->evenfkt=$fkevent;
		}
	
	
        function setidavis(string $idavis){
			$this->idavis=$idavis;
		}

        function gettitreevent(){
			return $this->titreevent;
		}
        function getcmntrevent(){
			return $this->cmntrevent;
		}
        function getnoteevent(){
			return $this->noteevent;
		}
        function getfkevent(){
			return $this->fkevent;
		}
		function getidavis()
        {
			return $this->idavis;
		}
    }
    

?>