<?php
require '../controller/eventC.php';
require '../controller/avisC.php';
$eventd=new eventc();
$evenements=$eventd->afficherevent();


$avisd = new avisC();
$aviss = $avisd->afficheravis();


 
?>


<!DOCTYPE html>
<html>





<style>
.header {
    padding: 60px;
    text-align: center;
    background: #1abc9c;
    color: white;
    font-size: 30px;
}
</style>


<header>

    <div class="header">
        <h1>LES MOYENNES</h1>
        <p> de nos Evenements</p>
    </div>



    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- CSS only -->
        <link rel="stylesheet" href="../css/style.css">
        <link rel="stylesheet" href="">
        <!-- JavaScript Bundle with Popper -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous">
        </script>
        <title>NADHAFNI</title>
        <link rel="stylesheet" type="text/css" href="../assets/css/formulaire_event.css">

    </head>



    <header>
        <input type="checkbox" name="" id="toggler">
        <label for="toggler" class="fas fa-bars"></label>

        <img class="logo" src="logo.png" alt="logo">

        <nav class="navbar">
            <a href="#home">Acceuil</a>
            <a href="#about">Reclamation Lieu</a>
            <a class="event_sec" href="front event.php">Evenements</a>
            <a href="#products">Boutiques</a>
            <a href="action.html">Actions Individuelles</a>
            <a href="#review">Forum</a>
            <a href="#contact">contact</a>

        </nav>

        <div class="icons">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-shopping-cart"></a>
            <a href="#" class="fas fa-user"></a>
        </div>

    </header>









    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

    <head>
        <meta charset="UTF-8" />
        <link rel="stylesheet" type="text/css" href="../css/events.css" />


    </head>

    <body>

        <?php 
   foreach($evenements as $value){
    $output=$avisd->moyenne_avis($value['idevent']);
   ?>
        <div class="card rgb">
            <div class="card-image card2"></div>
            <div class="card-text card2">
                <span class="date"><?php echo $value["dateevent"]; ?></span>
                <h2><?php echo $value["nomevent"];?></h2>
                <h3> MOYENNE DES AVIS : </h3>
                <h1> <?php echo(number_format($output['0']['moyenne'],2,"."," ")) ; ?></h1>

                <p>
                    <?php $i=0; 
            for ($i = 1; $i<$output['0']['moyenne']; $i++) {
                ?>

                    <img src="../images/star.png" height="20" width="35">

                    <?php
            }
            ?>


                <p>

                <h4> <?php echo('/10') ; ?></h4>
            </div>
        </div>
        <?php
     }
    ?>


        <script src="vanilla-tilt.min.js"></script>
        <script>
        VanillaTilt.init(document.querySelectorAll(".card"), {
            glare: true,
            reverse: true,
            "max-glare": 0.15
        });
        </script>
    </body>

</html>