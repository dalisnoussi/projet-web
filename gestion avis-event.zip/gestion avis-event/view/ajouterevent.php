<?php
require_once '../controller/eventC.php';
require_once '../Model/event.php';

if (isset($_POST['idevent']) && isset($_POST['nomevent']) && isset($_POST['lieuevent']) && isset($_POST['dateevent']) && isset($_POST['descripevent']))
{$eventsaisie= new event($_POST['idevent'],$_POST['nomevent'],$_POST['lieuevent'],$_POST['dateevent'],$_POST['descripevent']);
$eventc= new eventc();
$eventc->ajouterevent($eventsaisie);
header('Location:afficherListeevents.php');

}



?>


<script src="../js/verif_event.js"> </script>





<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content=
        "width=device-width, initial-scale=1.0">
    <title>
       
    </title>
 
    <style>
 
        /* Styling the Body element i.e. Color,
        Font, Alignment */
        body {
            background-color: #05c46b;
            font-family: Verdana;
            text-align: center;
        }
 
        /* Styling the Form (Color, Padding, Shadow) */
        form {
            background-color: #fff;
            max-width: 500px;
            margin: 50px auto;
            padding: 30px 20px;
            box-shadow: 2px 5px 10px rgba(0, 0, 0, 0.5);
        }
 
        /* Styling form-control Class */
        .form-control {
            text-align: left;
            margin-bottom: 25px;
        }
 
        /* Styling form-control Label */
        .form-control label {
            display: block;
            margin-bottom: 10px;
        }
 
        /* Styling form-control input,
        select, textarea */
        .form-control input,
        .form-control select,
        .form-control textarea {
            border: 1px solid #777;
            border-radius: 2px;
            font-family: inherit;
            padding: 10px;
            display: block;
            width: 95%;
        }
 
        /* Styling form-control Radio
        button and Checkbox */
        .form-control input[type="radio"],
        .form-control input[type="checkbox"] {
            display: inline-block;
            width: auto;
        }
 
        /* Styling Button */
        button {
            background-color: #05c46b;
            border: 1px solid #777;
            border-radius: 2px;
            font-family: inherit;
            font-size: 21px;
            display: block;
            width: 100%;
            margin-top: 50px;
            margin-bottom: 20px;
        }
    </style>
</head>
  


<a class="btn btn-outline-light float-right" href="back html file.php
">retour a la page d'accueil</a>

 <body>
    <h1>ajouter evenement</h1>
  
    <!-- Create Form -->
    <form id="form" action="" method="POST" onsubmit="return verif();">
 
        <!-- Details -->
        <div class="form-control">
            <label for="name" >
                id d'evenement
            </label>
 
            <!-- Input Type Text -->
            <input type="text"
                   id="idevent"
                   placeholder="l'id d'evenement"
                   name="idevent" />
        </div>
  
        <div class="form-control">
            <label for="email" >
            nom d'evenement
            </label>
 
            <!-- Input Type Email-->
            <input type="text"
                   id="nomevent"
                   placeholder="nom d'evenement"
                   name="nomevent" />
        </div>
  
        <div class="form-control">
            <label for="age" >
            lieu d'evenement
            </label>
 
            <!-- Input Type Text -->
            <input type="text"
                   id="lieuevent"
                   placeholder="lieu d'evenement"
                   name="lieuevent" />
        </div>
  

        <div class="form-control">
        <label for="descripevent">description  d'evenement:
        </label>
        

        <div>
       <input type="text" id="descripevent" name="descripevent" > 
       <div\>


        
          
    

        <label for="dateevent">date d'evenement:
       </label>
        
       <input type="date" id="dateevent" name="dateevent" > 
        


  


        
  
       <br>

  
        <!-- Multi-line Text Input Control -->
        <input value="ajouter evenement" type="submit" value="submit" onclick="verif()" >
        <br>

        <input type="reset" value="reset" id="reset">
    </form>
</body>
  
</html>








<!--


<form action="" method="POST" onsubmit="return verif();">
<table border="2" align="center">      
      <tr>
 <td>
<label for="idevent">id d'evenement:
      </label>
</td>
<td>  <input type="text" id="idevent" name="idevent" > </td>
</tr>
<tr>
<td>
      <label for="nomevent">Nom d'evenement:
      </label>
      </td>
      <td>  <input type="text" id="nomevent" name="nomevent" > </td>
      </tr>

      <tr>
 <td>
      <label for="lieuevent">lieu d'evenement:
      </label>
      </td>
      <td>  <input type="text" id="lieuevent" name="lieuevent" > </td>
      </tr>
      <tr>



    <tr>
 <td>
      <label for="dateevent">date d'evenement:
     </label>
     </td>
     <td><input type="date" id="dateevent" name="dateevent" > </td>
    </tr>


    <tr>
 <td>
      <label for="descripevent">description  d'evenement:
    </label>
    </td>
    <td><input type="text" id="descripevent" name="descripevent" > </td>
    </tr>

    <td> <input type="submit" name="add" value="add" onclick="verif()" /> </td>
    <td><input type="reset" value="reset" id="reset"> </td>
</p>
</fieldset>
      </table>
</form>

