

function verif_id()
{
    var word = document.getElementById("idevent").value;

    var numbers = /^[0-9]+$/
    if (word.match(numbers)) {
        return true;
    }
    else {
        return false;
    }




}







function verif_date() {
    var date = document.getElementById("dateevent").value;
    var date1 = new Date(date);
    var date2 = Date.now();
    if (date2 > date1) {

        return false;
    }
}





function verif_lieu() {
    var word = document.getElementById("lieuevent").value;
    var letters = /^[A-Za-z]+$/;
    if (word.match(letters)) {
        return true;
    }
    else {
        return false;
    }
}



function verif() {

    if (verif_id() == false) {
        alert('l id doit etre tous en chiffres');
        return false;
    }
    

    
    

    if (verif_date() == false) {
        alert("La date de l'evenement doit être antérieure à la date actuelle.");
        return false;
    }

    if (verif_lieu() == false) {
        alert('le lieu doit etre tous en lettres');
        return false;
    }

  return true;


}

