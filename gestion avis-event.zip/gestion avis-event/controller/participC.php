<?php
require '../config.php';

class participc{
function afficherparticip(){
$requete="select * from participation";
$config= config::getConnexion();
try{
$query=$config->prepare($requete);
$query->execute();
$result=$query->fetchAll();
return $result;
}catch (PDOException $e)


{
$e->getMesssage();
}


}



function getparticipbyid($id){
    $requete="select * from participation where idevent=:id ";
    $config= config::getConnexion();
    try{
    $query=$config->prepare($requete);
    $query->execute(
  [ 
    'id'=>$id
  ]
    );
    $result=$query->fetch();
    return $result;
    }catch (PDOException $e)
    {
    $e->getMesssage();
    }
}











 function ajouterparticip($particip) { 
  
     $config= config::getConnexion();

  try{
    $query=$config->prepare(
   'INSERT INTO participation(nomparticip,prenomparticip)
    VALUES(:nomparticip,:prenomparticip)');

  $query->execute([ 
    
    'nomparticip'=>$particip->getnomparticip(),
    'prenomparticip'=>$particip->getprenomparticip(),
    
  ]); 
  }catch(PDOException $e){
    $e->getMessage();
  }
 }











 function supprimerparticip($id){
   
    $config  = config::getConnexion();

   try{
    $querry=$config->prepare(
  'DELETE FROM participation WHERE idparticip =:id
  ');

  $querry->execute([ 
    'id'=>$id

  ]); 
    }catch(PDOException $e){
    $e->getMessage();
  }}






  

}
?>