function verif_titre(){

 

  var word = document.getElementById("titreevent").value;
  var letters = /^[A-Za-z]+$/;
  if (word.match(letters)) {
      return true;
  }
  else {
      return false;
  }


  
}

function verif_note(){
 
    var noteevent=document.getElementById("noteevent").value;
     if ((noteevent>10)||(noteevent<0))
           {return false;}
           else {return true;}
            
                    }




 function verif() {

  if (verif_titre() == false) {
    alert("le nom  doit contenir des lettres  seulement  !");
      return false;
  }
  

  if (verif_note() == false) {
    alert ("la note doit etre entre 0 et 10 ");
      return false;
               }

 

return true;


}
