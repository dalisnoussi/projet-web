<?php

    require_once '../config.php';
    require_once '../Model/avis.php';
    require_once '../Model/event.php';

    Class avisC {

        function afficheravis()
        {
            $requete = "select * from avis";
            $config = config::getConnexion();
            try {
                $querry = $config->prepare($requete);
                $querry->execute();
                $result = $querry->fetchAll();
                return $result ;
            } catch (PDOException $th) {
                 $th->getMessage();
            }
        }


        function getavisbyID($id)
        {
            $requete = "select * from avis where idavis=:id";
            $config = config::getConnexion();
            try {
                $querry = $config->prepare($requete);
                $querry->execute(
                    [
                        'id'=>$id
                    ]
                );
                $result = $querry->fetch();
                return $result ;
            } catch (PDOException $th) {
                 $th->getMessage();
            }
        }







        function ajouteravis($avis)
        {
            $config = config::getConnexion();
            try {
                $querry = $config->prepare('
                INSERT INTO avis 
                (idavis,cmntrevent,noteevent,fkevent,titreevent)  VALUES
                (:idavis,:cmntrevent,:noteevent,:fkevent,:titreevent)
                ');
                $querry->execute([
                   
                    'cmntrevent'=>$avis->getcmntrevent(),
                    'noteevent'=>$avis->getnoteevent(),
                    'fkevent'=>$avis->getfkevent(),
                    'titreevent'=>$avis->gettitreevent(),
                    'idavis'=>$avis->getidavis(),
                ]);
            } catch (PDOException $th) {
                 $th->getMessage();
            }
        }



 













        function modifieravis($avis,$idavis)
        {
            $config = config::getConnexion();
            try {
                $querry = $config->prepare(
                'UPDATE avis SET  cmntrevent=:cmntrevent,noteevent=:noteevent,titreevent=:titreevent
               
                where idavis=:idavis' );

                $querry->execute([
                    'idavis'=>$idavis,
                    'cmntrevent'=>$avis->getcmntrevent(),
                    'noteevent'=>$avis->getnoteevent(),
                    'titreevent'=>$avis->gettitreevent(),
                    
                    
                ]);
            } catch (PDOException $th) {
                 $th->getMessage();
            }
        }











        function supprimeravis($id)
        {
            $config = config::getConnexion();
            try {
                $querry = $config->prepare(
                'DELETE FROM avis WHERE idavis =:id
                ');
                $querry->execute([
                    'id'=>$id
                ]);
                
            } catch (PDOException $th) {
                 $th->getMessage();
            }
        }








        public function afficher_avis($idevent)
        {
         
            try {
              $config = config::getConnexion();
              $query = $config->prepare(
                'SELECT * FROM avis where fkevent=:id'
                );
                $query->execute([
                'id'=>$idevent
                      ]);
                return $query->fetchAll() ;
      
            } catch (PDOException $th) {
                 $th->getMessage();
            }
        }



  

        public function afficher_avisbyname($search)
        {
         
            try {
              $config = config::getConnexion();
              $query = $config->prepare(
                'SELECT  * from avis where titreevent like "%'.$search.'%"');
                $query->execute();
                return $query->fetchAll() ;
      
            } catch (PDOException $th) {
                 $th->getMessage();
            }
        }




      public function moyenne_avis($idevent)
        {
         
            try {
               $config = config::getConnexion();
               $query = $config->prepare(
                'SELECT AVG(noteevent) AS moyenne FROM avis where fkevent=:idevent');
                $query->execute([
                    'idevent'=>$idevent,
                
                   

                ]);
               return $query->fetchAll();
      
            } catch (PDOException $th) {
                 $th->getMessage();
            }
        }


    }

?>