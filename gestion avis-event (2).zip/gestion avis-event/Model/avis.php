<?php
    class avis
    {   
        private $titreevent;
        private $cmntrevent;
        private $noteevent;
		


        function __construct($titreevent,$cmntrevent,$noteevent){
			$this->titreevent=$titreevent;
			$this->cmntrevent=$cmntrevent;
			$this->noteevent=$noteevent;
		
		}
	
		
        function settitreevent(string $titreevent){
			$this->titreevent=$titreevent;
		}
        function setcmntrevent(string $cmntrevent){
			$this->cmntrevent=$cmntrevent;
		}
        function setnoteevent(int $noteevent){
			$this->noteevent=$noteevent;
		}
     
	
        function gettitreevent(){
			return $this->titreevent;
		}
        function getcmntrevent(){
			return $this->cmntrevent;
		}
        function getnoteevent(){
			return $this->noteevent;
		}

        
    }
    

?>