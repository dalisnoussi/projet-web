function readmore() {
    var dots = document.getElementById("dots");
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("myBtn");
  


    
    if (dots.style.display === "none") {
      dots.style.display = "inline";
      btnText.innerHTML = "lire plus";
      moreText.style.display = "none";
     } else {
      dots.style.display = "none";
      btnText.innerHTML = "lire moins";
      moreText.style.display = "inline";
    }


  }







