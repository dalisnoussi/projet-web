<?php
require '../controller/participC.php';
$participc=new participc();
$participc->supprimerparticip($_GET['idparticip']);
header('Location:afficherListeparticip.php');


?>