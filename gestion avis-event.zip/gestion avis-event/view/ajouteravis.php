<?php

    require_once     '../controller/avisC.php';
    require_once '../Model/avis.php' ;
    require_once     '../controller/eventC.php';
    
  


    if (  isset($_POST['cmntrevent'] ) && isset($_POST['noteevent'] )&& isset($_POST['fkevent'] )&& isset($_POST['titreevent'] ) )
      
    { 
            $avis = new avis(NULL,$_POST['titreevent'],$_POST['cmntrevent'],($_POST['noteevent']) ,($_POST['fkevent'] ));
                
            $avisC = new avisC();
            $avisC->ajouteravis($avis);
            header('Location:afficherListeavis.php');
    }
  
    else {
        $eventC = new eventC();
        $resultats = $eventC -> afficherevent();
      }

?>




<script src="verifavis.js"> </script>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="">
    <link rel="stylesheet" href="../css/boutons.css">
    <!-- JavaScript Bundle with Popper -->
    <link rel="stylesheet" href="../css/bts.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    <title>NADHAFNI</title>
    <link rel="stylesheet" type="text/css" href="../assets/css/formulaire_event.css">

</head>





<body>

<header>

    <input type="checkbox" name="" id="toggler">
    <label for="toggler" class="fas fa-bars"></label>

    <img class="logo" src="logo.png" alt="logo">

    <nav class="navbar">
        <a href="#home">Acceuil</a>
        <a href="#about">Reclamation Lieu</a>
        <a  class="event_sec" href="front event.php">Evenements</a> 
        <a href="#products">Boutiques</a>
        <a href="action.html">Actions Individuelles</a>  
        <a href="#review">Forum</a>
        <a href="#contact">contact</a>

    </nav>

    <div class="icons">
        <a href="#" class="fas fa-heart"></a>
        <a href="#" class="fas fa-shopping-cart"></a>
        <a href="#" class="fas fa-user"></a>
    </div>

</header>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>








<body>

<!-- header section starts  -->




	<form id="form" action="" method="POST" onsubmit="return verif();">
	<div class="bg-contact3" style="background-image: url('images/bg-01.jpg');">
		<div class="container-contact3">
			<div class="wrap-contact3">
				<form class="contact3-form validate-form">
					<span class="contact3-form-title">
						NOTER NOS EVENEMENTS
					</span>


               
					<div class="wrap-input3 validate-input" >
						<input class="input3" id="titreevent" type="text" name="titreevent" placeholder="lieu event">
						<span class="focus-input3"></span>
					</div>


					
					<div class="wrap-input3 validate-input" >
						<input class="input3" id="cmntrevent" type="text" name="cmntrevent" placeholder="commentaire">
						<span class="focus-input3"></span>
					</div>

	

                    <div class="wrap-input3 validate-input" >
						<input class="input3" id="noteevent" type="number" name="noteevent" placeholder="note evenement">
						<span class="focus-input3"></span>
					 </div>
		


                     <select name="fkevent">
                     <option value="" >choisir l'evenement-</option>

                     <?php foreach ($resultats as $value) {
                      ?>
                      <option value="<?php echo($value["idevent"])?>"> <?php echo($value["nomevent"])?></option>

                      <?php }?>
                     </select>
                         <br>
                         <br>
                         <br>
                         <br>
                         

                    <input class="bts"  value="ajouter " type="submit" value="submit" >

					


				</form>
			</div>
		</div>
	</div>


	<div id="dropDownSelect1"></div>
</form>








<footer>

    <section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="#">Acceuil</a>
            <a href="#">A propos Nous</a>
            <a href="#">Produits</a>
            <a href="#">review</a>
            <a href="#">contact</a>
        </div>
      
        <div class="box">
            <h3>Social Media</h3>
            <i class="fab fa-facebook"></i> <br>
           <i class="fab fa-instagram"></i><br>
           <i class="fab fa-youtube"></i><br>

             
    
        </div>

        <div class="box">
            <h3>locations</h3>
            <a href="#">Ariana</a>
            <a href="#">Nabeul</a>
            <a href="#">Sousse</a>
            <a href="#">Tunis</a>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <a href="#">+216 28 683 199</a>
            <a href="#">NADHAFNI@gmail.com</a>
            <a href="#">Petite Ariana</a>
            <img src="images/payment.png" alt="">
        </div>

    </div>

   <div class="credit"> created by <span> The Mythical Developers </span> | all rights reserved </div>
</footer>

</section>




</body>
</html>































