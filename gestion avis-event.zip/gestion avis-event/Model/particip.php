<?php
    class particip
    {   
        private $nomparticip;
        private $prenomparticip;
        
		


        function __construct($nomparticip,$prenomparticip){
			$this->nomparticip=$nomparticip;
			$this->prenomparticip=$prenomparticip;
			
		}
	
		
        function setnomparticip(string $nomparticip){
			$this->nomparticip=$nomparticip;
		}
        function setprenomparticip(string $prenomparticip){
			$this->prenomparticip=$prenomparticip;
		}
     
     
	
        function getnomparticip(){
			return $this->nomparticip;
		}
        function getprenomparticip(){
			return $this->prenomparticip;
		}


        
    }
    

?>