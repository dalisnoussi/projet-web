


function ValidateEmail_mdp(){

 

   var email=document.getElementById("email").value;
   if (email.includes('@nadhfni.tn')) {} else {alert("verifier que votre mail est de type @nadhfni.tn ");
     return ;}
   


 

   var motdepasse=document.getElementById("password").value;
    if (motdepasse.length<8)
          {alert ("mot de passe doit avoir 8 caracteres");
             return;}

    


   var nom=document.getElementById("nom").value;
   
     if( allLetter(nom)===false){alert("le nom  doit contenir des lettres  seulement !"); return;}
     if( startsWithCapital(nom)==false){alert("premier lettre du nom doit etre en majiscule!");
     return;}


   var prenom=document.getElementById("prenom").value;
   
          if(allLetter(prenom)===false){alert("le prenom  doit contenir des lettres  seulement !");return;}
          if( startsWithCapital(prenom)==false){alert("premier lettre du prenom doit etre en majiscule!");return;}
}