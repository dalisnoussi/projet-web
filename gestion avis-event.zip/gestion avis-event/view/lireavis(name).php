<?php


require '../controller/avisC.php';

$avisc = new avisc();


if (isset($_POST['search'])) {
  $list = $avisc->afficher_avisbyname($_POST['search']);
} else {
  $avis = $avisc->afficheravis();
}

?>


<script src="../js/verif_avis.js"> </script>





<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- CSS only -->
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="">
  <link rel="stylesheet" href="../css/boutons.css">
  <!-- JavaScript Bundle with Popper -->
  <link rel="stylesheet" href="../css/bts.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
  <title>NADHAFNI</title>
  <link rel="stylesheet" type="text/css" href="../assets/css/formulaire_event.css">

</head>






<header>

  <input type="checkbox" name="" id="toggler">
  <label for="toggler" class="fas fa-bars"></label>

  <img class="logo" src="logo.png" alt="logo">

  <nav class="navbar">
    <a href="#home">Acceuil</a>
    <a href="#about">Reclamation Lieu</a>
    <a class="event_sec" href="front event.php">Evenements</a>
    <a href="#products">Boutiques</a>
    <a href="action.html">Actions Individuelles</a>
    <a href="#review">Forum</a>
    <a href="#contact">contact</a>

  </nav>

  <div class="icons">
    <a href="#" class="fas fa-heart"></a>
    <a href="#" class="fas fa-shopping-cart"></a>
    <a href="#" class="fas fa-user"></a>
  </div>

</header>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<body>




  <form id="form" action="" method="POST">



    <input type="search" name="search" placeholder="taper le lieu de l'evenement">
    <input type="submit" name="envoyer" >
  </form>




  <?php if (isset($avis)) { ?>
    <table id="customers">
      <tr>
        <th>numero d'avis</th>
        <th>lieu d'event</th>
        <th>commentaire</th>
        <th>note </th>
      </tr>

      <?php $i = 1 ?>

  


      <?php foreach ($avis as $avis) {
        ?>
          <tr>
            <td> <?php echo $i++; ?></td>
            <td><?php echo $avis['titreevent']; ?></td>
            <td><?php echo $avis['cmntrevent']; ?></td>
            <td><?php echo $avis['noteevent']; ?></td> 

        <?php }
     }
     else {  ?>   
       
        <table id="customers">
          <tr>
            <th>numero d'avis</th>
            <th>lieu d'event</th>
            <th>commentaire</th>
            <th>note </th>
          </tr>

          <?php
                 $i=1;

          foreach ($list as $list) {
            ?>

              <tr>
                <td> <?php echo $i++; ?></td>
                <td><?php echo $list['titreevent']; ?></td>
                <td><?php echo $list['cmntrevent']; ?></td>
                <td><?php echo $list['noteevent']; ?></td>
              <?php
              }
           }
                if($list==NULL) {echo "<td>l'evenement n'existe</td>";} 
           
            ?>



           
          

        </table>


        <style>
          #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
          }

          #customers td,
          #customers th {
            border: 1px solid #ddd;
            padding: 8px;
          }

          #customers tr:nth-child(even) {
            background-color: #f2f2f2;
          }

          #customers tr:hover {
            background-color: #ddd;
          }

          #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #04AA6D;
            color: white;
          }
        </style>
</body>




<footer>

  <section class="footer">

    <div class="box-container">

      <div class="box">
        <h3>quick links</h3>
        <a href="#">Acceuil</a>
        <a href="#">A propos Nous</a>
        <a href="#">Produits</a>
        <a href="#">review</a>
        <a href="#">contact</a>
      </div>

      <div class="box">
        <h3>Social Media</h3>
        <i class="fab fa-facebook"></i> <br>
        <i class="fab fa-instagram"></i><br>
        <i class="fab fa-youtube"></i><br>



      </div>

      <div class="box">
        <h3>locations</h3>
        <a href="#">Ariana</a>
        <a href="#">Nabeul</a>
        <a href="#">Sousse</a>
        <a href="#">Tunis</a>
      </div>

      <div class="box">
        <h3>contact info</h3>
        <a href="#">+216 28 683 199</a>
        <a href="#">NADHAFNI@gmail.com</a>
        <a href="#">Petite Ariana</a>
        <img src="images/payment.png" alt="">
      </div>

    </div>

    <div class="credit"> created by <span> The Mythical Developers </span> | all rights reserved </div>
</footer>

</section>






</html>